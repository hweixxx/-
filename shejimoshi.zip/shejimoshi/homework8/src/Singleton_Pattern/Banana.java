package Singleton_Pattern;

public class Banana extends MyFruit {
	public Banana() {
		kind = "Banana";
	}
}
