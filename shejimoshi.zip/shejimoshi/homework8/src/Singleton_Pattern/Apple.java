package Singleton_Pattern;

public class Apple extends MyFruit {
	public Apple() {
		kind = "Apple";
	}
}
