package Simple_factory;

public class Fruit {

    public void eat(){
    }

}
