package Factory_method_pattern;

public class Banana extends Fruit {
	public void eat() {
		System.out.println("eat Banana");
	}
}
