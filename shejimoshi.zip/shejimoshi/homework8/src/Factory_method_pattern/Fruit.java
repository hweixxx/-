package Factory_method_pattern;

public class Fruit {

    public void eat(){
    }

}
