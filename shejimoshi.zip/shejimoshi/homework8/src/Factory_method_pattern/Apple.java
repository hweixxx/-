package Factory_method_pattern;

public class Apple extends Fruit {
	public void eat() {
		System.out.println("eat Apple");
	}
}
