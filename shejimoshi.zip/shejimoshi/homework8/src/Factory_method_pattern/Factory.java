package Factory_method_pattern;

public class Factory {

    public Fruit CreateFruit(){
        return null;
    }

}
