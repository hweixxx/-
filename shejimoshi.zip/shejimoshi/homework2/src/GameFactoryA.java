public class GameFactoryA extends GameFactory{
	 public Role CreateR(){
	    	return new Arole();
	    }
}
