public class GameFactoryC extends GameFactory{
	public Role CreateR() {
		return new Crole();
	}
}
