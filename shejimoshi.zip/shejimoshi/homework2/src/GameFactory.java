public class GameFactory {

    public Role CreateR(){
		/*
		 * if(kind.equals("A")) return new Arole(); if(kind.equals("B")) return new
		 * Brole(); if(kind.equals("C")) return new Crole(); return null;
		 */
    	return null;
    }

}
