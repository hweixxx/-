public class GameFactoryB extends GameFactory{
	public Role CreateR() {
		return new Brole();
	}
}
