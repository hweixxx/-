package Visitor_Pattern;

public interface IProduct {
	void accept(AVisitor visitor);
}
