package State_Pattern;

public class DeadState extends ThreadState {

    public DeadState(){
    	System.out.println("�߳�����!");
    }

}
