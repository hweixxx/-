package State_Pattern;

public abstract class ThreadState {
    protected int state;// ״̬��
}
