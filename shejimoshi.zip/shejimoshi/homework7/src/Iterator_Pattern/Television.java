package Iterator_Pattern;

public interface Television {
	TVIterator createIterator();
}
