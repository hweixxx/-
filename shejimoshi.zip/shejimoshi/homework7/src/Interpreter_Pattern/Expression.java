package Interpreter_Pattern;

public interface Expression {
	public boolean interpret(String contex);
}
