package Strategy_Pattern;

public class FruitKnife implements ICutFruit {

	public void CutStrategy(String fruitname) {
		System.out.println(fruitname + "һ�α��г�һƬ��");
	}

}
