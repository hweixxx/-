package Strategy_Pattern;

public interface ICutFruit {

    public void CutStrategy(String fruitname);

}
