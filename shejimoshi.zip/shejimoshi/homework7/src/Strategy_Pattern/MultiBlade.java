package Strategy_Pattern;

public class MultiBlade implements ICutFruit {

	public void CutStrategy(String fruitname) {
		System.out.println(fruitname + "һ�α��гɰ˰����");
	}

}
