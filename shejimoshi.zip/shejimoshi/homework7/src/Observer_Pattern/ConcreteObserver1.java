package Observer_Pattern;

public class ConcreteObserver1 implements ObserverO {

    public void response(){
    	System.out.println("Ŀ��仯�ˣ�1�ķ�Ӧ");
    }

}
