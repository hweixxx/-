package Observer_Pattern;

public class ConcreteObserver2 implements ObserverO {

    public void response(){
    	System.out.println("Ŀ��仯�ˣ�2�ķ�Ӧ");
    }

}
