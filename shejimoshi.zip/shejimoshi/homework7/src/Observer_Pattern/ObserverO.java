package Observer_Pattern;

public interface ObserverO {

    public void response();//��Ӧ

}
