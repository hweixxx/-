public interface NewJuicer {

    public String newPort(String fruit1, String fruit2);

}
