public class SubMixMyFruitB extends MixMyFruit {

	public void buildFruit1() {
		myFruit.setFruit1("����");
	}

	public void buildFruit2() {
		myFruit.setFruit2("��ݮ");
	}

}
