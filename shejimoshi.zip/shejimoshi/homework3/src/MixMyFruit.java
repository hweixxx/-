public class MixMyFruit {
    protected MyFruit myFruit = new MyFruit();
    public void buildFruit1(){
    }

    public void buildFruit2(){
    }
    public MyFruit getMyFruit(){
        return myFruit;
    }

}
