public class SubMixMyFruitA extends MixMyFruit {

    public void buildFruit1(){
    	myFruit.setFruit1("ƻ��");
    }

    public void buildFruit2(){
    	myFruit.setFruit2("����");
    }

}
