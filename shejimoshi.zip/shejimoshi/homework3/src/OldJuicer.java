public class OldJuicer {

    public String onePort(String fruit){
        String str = fruit;
        return str;
    }

}
