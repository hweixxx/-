
public class Drink {
}
