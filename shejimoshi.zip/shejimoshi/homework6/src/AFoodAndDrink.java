
public interface AFoodAndDrink {
	Cola cola = new Cola();
	Chicken_leg_fort chicken_leg_fort = new Chicken_leg_fort();
}
