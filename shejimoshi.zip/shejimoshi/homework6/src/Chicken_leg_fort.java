
public class Chicken_leg_fort extends Food{
	String chicken_leg_fort;
	public Chicken_leg_fort() {
		this.chicken_leg_fort = "���ȱ�";
	}
	public String getFood() {
		return chicken_leg_fort;
	}
}
