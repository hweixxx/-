
public class Fruit_juice extends Drink{
	String fruit_juice;
	public Fruit_juice() {
		this.fruit_juice = "һ����֭";
	}
	public String getDrink() {
		return fruit_juice;
	}
}
