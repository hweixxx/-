
public class Cola extends Drink{
	String cola;
	public Cola() {
		this.cola = "һ������";
	}
	public String getDrink() {
		return cola;
	}
}
