
public class Food {

}
