
public class Chicken_roll extends Food{
	String chicken_roll;
	public Chicken_roll() {
		this.chicken_roll = "�����";
	}
	public String getFood() {
		return chicken_roll;
	}
}
