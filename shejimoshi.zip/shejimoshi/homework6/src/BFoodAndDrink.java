
public interface BFoodAndDrink {
	Fruit_juice fruit_juice = new Fruit_juice();
	Chicken_roll chicken_roll = new Chicken_roll();
}
