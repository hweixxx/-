public class material_B extends material {
	
    public material_B() {
    	kind = "material_B";
    }

}
