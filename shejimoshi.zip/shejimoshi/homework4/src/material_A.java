public class material_A extends material {

    public material_A() {
    	kind = "material_A";
    }
}
