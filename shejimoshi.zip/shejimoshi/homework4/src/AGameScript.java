public interface AGameScript {  
    public material CreateM();
    public equipment CreateE();
}
