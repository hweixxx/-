public class equipment_A extends equipment {

    public equipment_A() {
    	kind = "equipment_A";
    }
}
