public class equipment_B extends equipment {

    public equipment_B() {
    	kind = "equipment_A";
    }
}
