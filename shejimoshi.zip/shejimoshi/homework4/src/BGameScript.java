public interface BGameScript {
    public material CreateM() ;
    public equipment CreateE() ;
}
