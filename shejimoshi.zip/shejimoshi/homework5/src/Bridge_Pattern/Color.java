package Bridge_Pattern;

public interface Color {

    public void bepaint(String penType, String name);

}
