package Bridge_Pattern;

public class MiddlePen extends Pen {

    public void draw(String name){
    	String penType = "�кź�ë�ʻ���";
    	this.color.bepaint(penType, name);
    }

}
