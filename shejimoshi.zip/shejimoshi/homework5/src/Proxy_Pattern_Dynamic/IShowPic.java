package Proxy_Pattern_Dynamic;

public interface IShowPic {
	public void ShowPic(String picname); 
}
