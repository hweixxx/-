package Proxy_Pattern_Dynamic;

public interface ITestInterface {
	public void SendMessage(String mes);
}
