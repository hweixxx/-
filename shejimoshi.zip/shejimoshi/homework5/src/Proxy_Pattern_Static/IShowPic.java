package Proxy_Pattern_Static;

public interface IShowPic {
	public void ShowPic(String picname); 
}
