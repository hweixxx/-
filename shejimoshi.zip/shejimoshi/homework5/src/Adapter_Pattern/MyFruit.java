package Adapter_Pattern;

public class MyFruit{
	protected String kind;

	public String Get() {
		return kind;
	}
}
