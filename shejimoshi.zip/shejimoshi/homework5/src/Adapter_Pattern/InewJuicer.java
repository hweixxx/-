package Adapter_Pattern;

public interface InewJuicer {

    public String newPort(MyFruit fruit1, MyFruit fruit2);

}
