package Composite_Pattern;

public class Banana extends MyElement {

    public void eat(){
    	System.out.println("���㽶��");
    }

}
