package Composite_Pattern;

public class Apple extends MyElement {

    public void eat(){
    	System.out.println("��ƻ����");
    }

}
