package Composite_Pattern;

public abstract class MyElement {

    public abstract void eat();

}
