package Composite_Pattern;

public class Pear extends MyElement {

    public void eat(){
    	System.out.println("�����ӣ�");
    }

}
