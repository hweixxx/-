package Decorator_Pattern;

public interface IBirthdayCake {

    public void Show();

}
