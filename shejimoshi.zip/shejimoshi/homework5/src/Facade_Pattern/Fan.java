package Facade_Pattern;

public class Fan {

    public void on(){
    	System.out.println("���ȴ�!");
    }

    public void off(){
    	System.out.println("���ȹر�!");
    }

}
