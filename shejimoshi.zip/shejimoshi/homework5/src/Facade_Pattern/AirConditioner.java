package Facade_Pattern;

public class AirConditioner {

    public void on(){
    	System.out.println("�յ���!");
    }

    public void off(){
    	System.out.println("�յ��ر�!");
    }

}
