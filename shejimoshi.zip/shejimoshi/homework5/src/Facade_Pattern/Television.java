package Facade_Pattern;

public class Television {

    public void on(){
    	System.out.println("���Ӵ�!");
    }

    public void off(){
    	System.out.println("���ӹر�!");
    }

}
