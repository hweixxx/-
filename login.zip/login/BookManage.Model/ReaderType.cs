﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    public class ReaderType
    {
        public int rdType { get; set; }
        public string rdTypeName { get; set; }
        public int CanLendQty { get; set; }
        public DateTime CanlendDay { get; set; }
        public int CanContinueTimes{ get; set; }
        public float PunishRate{ get; set; }
        public int DateValid { get; set; }
        public ReaderType() { }
        public ReaderType(ReaderType rt) {
            this.rdType = rt.rdType;
            this.rdTypeName= rt.rdTypeName;
            this.CanLendQty = rt.CanLendQty;
            this.CanlendDay = rt.CanlendDay;
            this.CanContinueTimes = rt.CanContinueTimes;
            this.PunishRate = rt.PunishRate;
            this.DateValid = rt.DateValid;
        }       
    }
}
