﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    class Book
    {
        public long BorrowID { get; set; }
        public int rdID { get; set; }
        public int bkID { get; set; }
        public int ldContinueTimes { get; set; }
        public DateTime ldDateOut { get; set; }
        public DateTime ldDateRetPlan { get; set; }
        public DateTime ldDateRetAct { get; set; }
        public int ldOverDay { get; set; }
        public float ldOverMoney { get; set; }
        public float ldPunishMoney { get; set; }
        public bool lsHasReturn { get; set; }
        public string OperatorLend { get; set; }
        public string OperatorRet { get; set; }
        public Book() { }
        public Book(Book rt)
        {
            this.BorrowID = rt.BorrowID;
            this.rdID = rt.rdID;
            this.bkID = rt.bkID;
            this.ldContinueTimes = rt.ldContinueTimes;
            this.ldDateOut = rt.ldDateOut;
            this.ldDateRetPlan = rt.ldDateRetPlan;
            this.ldDateRetAct = rt.ldDateRetAct;
            this.ldOverDay = rt.ldOverDay;
            this.ldOverMoney = rt.ldOverMoney;
            this.ldPunishMoney = rt.ldPunishMoney;
            this.lsHasReturn = rt.lsHasReturn;
            this.OperatorLend = rt.OperatorLend;
            this.OperatorRet = rt.OperatorRet;
        }
    }
}
