﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    public class Reader
    {
        public int rdID { get; set; }
        public string rdName { get; set; }
        public string rdSex { get; set; }
        public int rdType { get; set; }
        public string rdDept { get; set; }
        public string rdPhone { get; set; }
        public DateTime rdDateReg { get; set; }
        public Byte[] rdPhoto { get; set; }
        public string rdStatus { get; set; }
        public int rdBorrowQty { get; set; }
        public string rdPwd { get; set; }
        public int rdAdminRoles { get; set; }
        public Reader() { }
        public Reader(Reader rt) {
            this.rdID = rt.rdID;
            this.rdName = rt.rdName;
            this.rdSex = rt.rdSex;
            this.rdType = rt.rdType;
            this.rdDept = rt.rdDept;
            this.rdPhone = rt.rdPhone;
            this.rdDateReg = rt.rdDateReg;
            this.rdPhoto = rt.rdPhoto;
            this.rdStatus = rt.rdStatus;
            this.rdBorrowQty = rt.rdBorrowQty;
            this.rdPwd = rt.rdPwd;
            this.rdAdminRoles = rt.rdAdminRoles;
        }
    }
}
