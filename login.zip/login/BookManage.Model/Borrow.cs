﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManage.Model
{
    class Borrow
    {
        public int bkID { get; set; }
        public string bkCode { get; set; }
        public string bkName { get; set; }
        public string bkAuthor { get; set; }
        public string bkPress { get; set; }
        public DateTime bkDatePress { get; set; }
        public string bkISBN { get; set; }
        public string bkCatalog { get; set; }
        public int bkLanguage { get; set; }
        public int bkPages { get; set; }
        public int bkPrice { get; set; }
        public float bkDateIn { get; set; }
        public string bkBrief { get; set; }
        public Byte[] bkCover { get; set; }
        public string bkStatus { get; set; }
        public Borrow() { }
        public Borrow(Borrow rt) {
            this.bkID = rt.bkID;
            this.bkCode = rt.bkCode;
            this.bkName = rt.bkName;
            this.bkAuthor = rt.bkAuthor;
            this.bkPress = rt.bkPress;
            this.bkDatePress = rt.bkDatePress;
            this.bkISBN = rt.bkISBN;
            this.bkCatalog = rt.bkCatalog;
            this.bkLanguage = rt.bkLanguage;
            this.bkPages = rt.bkPages;
            this.bkPrice = rt.bkPrice;
            this.bkDateIn = rt.bkDateIn;
            this.bkBrief = rt.bkBrief;
            this.bkCover = rt.bkCover;
            this.bkStatus = rt.bkStatus;
        }
    }
}
