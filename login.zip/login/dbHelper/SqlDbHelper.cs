﻿using System.Data;
using System;
using System.Collections;
using System.Text;
using System.IO;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;

namespace dbHelper
{
    public class SqlDbHelper:IDisposable//改为static
    {
        private static string _connStr = @"Data Source=DESKTOP-ECD3EVK;Initial Catalog=Library;User ID=sa;Password=123;";
        private SqlConnection _conn;
        public void Dispose()
        {
            GC.SuppressFinalize(true);
        }
        static public void GetConnStr()
        {
            var encrypt = Convert.ToBoolean(ConfigurationManager.AppSettings["ConnEnctypt"]);
            _connStr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString.Trim();
            if(encrypt) 
                _connStr = Encrypt.DecryptDES(_connStr);   
        }
        static public SqlConnection GetConn()
        {
            if (_connStr == "")
                GetConnStr();
            var conn = new SqlConnection(_connStr);
            return conn;

        }
        public void OpenConnection()
        {
            _conn = GetConn();
            _conn.Open();
        }
        public void CloseConnection()
        {
            if (_conn.State != ConnectionState.Closed)
                _conn.Close();
        }
        //执行增删改查的方法
        public bool ExecuteNonQuery(string strCmd)
        {
            var cmd = new SqlCommand(strCmd);
            try
            {
                OpenConnection();
                cmd.Connection = _conn;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(Exception)
            {
                return false;
            }
            finally
            {
                CloseConnection();
            }
        }
        //执行查询，返回单个值
        public object ExecuteScalar(string strCmd)
           
        {
            var cmd = new SqlCommand();
             try
             {
                 OpenConnection();
                 cmd.Connection = _conn;
                 return cmd.ExecuteScalar();
             }
              catch(Exception)
              {
                 return null;
              }

             finally
             {
                 CloseConnection();
             }
        }
        //执行查询，返回多行
        public SqlDataReader ExecuteReader(string strCmd)
        {
            var cmd = new SqlCommand(strCmd);
            try
            {
                OpenConnection();
                cmd.Connection = _conn;
                return cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch(Exception)
            {
                CloseConnection();
                return null;
            }
        }
    }
}
