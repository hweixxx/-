﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//好像没有这个程序集
using System.Data;
using BookManage.Model;
using dbHelper;
namespace BookManage.DAL.dll
{
    public class ReaderTypeDAO
    {
        static void main(string[] args)
        {
            string constr = "Data Source=DESKTOP-ECD3EVK;Initial Catalog=Library;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                string sql="insert into TB_reader values('张三')";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    con.Open();
                    int r = cmd.ExecuteNonQuery();
                    Console.WriteLine("成功插入{0}行", r);
                }
            }
        }
        //public void Insert(ReaderType w)
        //{
        //    SqlDbHelper dbHelper = new SqlDbHelper();
        //    string sql = string.Format("INSERT INTO ReaderType VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}')",
        //        w.rdType, w.rdTypeName, w.CanLendQty, w.CanlendDay, w.CanContinueTimes, w.PunishRate, w.DateValid);
        //    dbHelper.ExecuteNonQuery(sql);
        //}
        //public void Update(ReaderType w)
        //{
        //    SqlDbHelper dbHelper = new SqlDbHelper();
        //    string sql = string.Format("UPDATE ReaderType SET rdType='{1}',Workersex='{2}'," +
        //        "Workerage='{3}',Workerdept='{4}' WHERE Workerno='{0}'",
        //        w.rdType, w.rdTypeName, w.CanLendQty, w.CanlendDay, w.CanContinueTimes, w.PunishRate, w.DateValid);
        //    dbHelper.ExecuteNonQuery(sql);
        //}




        //public static int Add(ReaderType readertype)
        //{
        //    int rows = 0;
        //    //dbhelper.SqlHelper dbHelper = new dbhelper.SqlHelper();
        //    string sql = "insert into TB_ReaderType(rdType,rdTypeName,CanLendQty,CanlendDay,CanContinueTimes,PunishRate,DateValid)" +
        //        "valus(@rdType,@rdTypeName,@CanLendQty,@CanlendDay,@CanContinueTimes,@PunishRate,@DateValid)";
        //    SqlParameter[] parameters ={
        //                                 new SqlParameter("@rdType",readertype.rdType),
        //                                 new SqlParameter("@rdTypeName",readertype.rdTypeName),
        //                                 new SqlParameter("@CanLendQty",readertype.CanLendQty),
        //                                 new SqlParameter("@CanLendDay",readertype.CanLendDay),
        //                                 new SqlParameter("@CanContinueTimes",readertype.CanContinueTimes),
        //                                 new SqlParameter("@PunishRate",readertype.PunishRate),
        //                                 new SqlParameter("@DateValid",readertype.DateValid)
        //                             };
        //    try
        //    {
        //        rows = dbhelper.SqDblHelper.ExecuteNonQuery(sql, parameters);
        //    }
        //    catch (SqlException ex)
        //    {

        //        throw new Exception(ex.Message);
        //    }

        //}

        //public void delete(ReaderType w)
        //{
        //    Sqldbhelper dbhelper = new Sqldbhelper();
        //    string sql = string.format("delete from worker where workerno='{0}'", rdType);
        //    dbhelper.executenonquery(sql);

        //}
    }
}
