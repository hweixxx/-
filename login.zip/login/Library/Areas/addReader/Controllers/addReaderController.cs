﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookManage.Model;
using dbHelper;
using BookManage.Model;
using System.Data.SqlClient;//好像没有这个程序集

namespace Library.Areas.addReader.Controllers
{
    public class addReaderController : Controller
    {
        //
        // GET: /addReader/addReader/
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult add()
        {
            Reader reader = new Reader();
            TryUpdateModel(reader);
            return View(reader);
            //Console.WriteLine("\n****************");
            //string rdName = Request.Form["rdName"];

            
           
            //string constr = "Data Source=DESKTOP-ECD3EVK;Initial Catalog=Library;Integrated Security=True";
            //using (SqlConnection con = new SqlConnection(constr))
            //{
            //    string sql = "insert into TB_reader values('"+rdName+"')";
            //    using (SqlCommand cmd = new SqlCommand(sql, con))
            //    {
            //        con.Open();
            //        int r = cmd.ExecuteNonQuery();
            //        Console.WriteLine("成功插入{0}行", r);
            //    }
            //}
        }
	}
}